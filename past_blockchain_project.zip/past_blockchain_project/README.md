# Gruppe1

## Gruppenmitglieder

- Valeria Robles Garzón
- Luca Lunati
- Maarten de Laat

## Projektumfang

- Erstellen von NFT mit einzigartigem Namen
- Kaufen und verkaufen an / von anderen Personen
- Eigenet NFT's und NFT's zum Verkauf werden im UI dargestellt

## Technologien

- Truffle fürs compilen und migraten vom "Contract"
- Reactjs fürs frontend
- Solidity als Programmiersprache für die contracts
- Web3 als Bibliothek für Contracts / Accounts mit Metamask

## Aufstarten von der Crypto Students App

- Im root Ordner bootstrap runterladen mit `npm install react-bootstrap bootstrap@5.1.3`
- Dann `npm install`
- Navigiere zum clients folder
- Dann `npm install`
- im terminal `npm start` ausführen





