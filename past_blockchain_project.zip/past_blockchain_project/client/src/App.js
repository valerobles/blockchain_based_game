import React, { useEffect, useState } from "react";
import NFT from "./contracts/NFT.json";
import getWeb3 from "./getWeb3";
import './dark_theme/css/mdb.dark.min.css';
import "./App.css";

const App=()=>{

  const PokemonObj = (name, price, id, owner) => { return { name: name, price: price, id: id, owner: owner } }
  const [web3, setWeb3] = useState();
  const [contract, setContract] = useState(null);
  const [account, setAccounts] = useState("");
  const [mintText, setMintText] = useState("");
  const [students, setStudents]= useState([PokemonObj()]);
  const [priceText, setPriceText] = useState("");
  const [studentId, setStudentId] = useState(0);
  
  const mint = () => {
    if (mintText.length > 0)
      contract.methods.mint(mintText).send({ from: account }, (error)=>{
        console.log("it worked")
        if(!error){
          let student = PokemonObj(mintText, priceText, studentId,account);
          setStudents([...students, student]);
          setMintText("");
          setPriceText("");
          setStudentId(students.length);
        
        }
      });
  }

   // load all the nfts
  const loadNFTS = async (contract) => {
    // get all NTFs from blockchain
    const totalSupply = await contract.methods.totalSupply().call();
    let newResults = [PokemonObj()];

    for(let i = 0; i < totalSupply; i++){
      let student = await contract.methods.students(i).call();
      let newStudent = (JSON.parse(JSON.stringify(student))); //use json
      let newStudenPrice = newStudent.price / 1000000000000000000; //convert wei to ether
      let studentToOwner = await contract.methods.studentToOwner(i).call();
      let newStudent2 = PokemonObj(newStudent.name, newStudenPrice, newStudent.id, studentToOwner);
      newResults.push(newStudent2);
    }
    setStudents(newResults);

  }

    // load web3 account from metamask
  const loadWeb3Acc = async (web3) => {
    const accounts = await web3.eth.getAccounts();
    if(accounts){
      setWeb3(web3);
      setAccounts(accounts[0]);
    }
  }

    // load the contract
  const loadWeb3Contract = async (web3) => {
    const networkId = await web3.eth.net.getId();
    const networkData = NFT.networks[networkId];
    if(networkData){
      const abi = NFT.abi;
      // for local blockchain testing
      // const address = networkData.address;
      // const contract = new web3.eth.Contract(abi, address);
      const contract = new web3.eth.Contract(abi, "0xDaE477F7A95B4Ef701D25917119E83864780cb19");
      setContract(contract);
      return contract;
    }
  }


 useEffect(async () => {
  const web3 = await getWeb3();
  await loadWeb3Acc(web3);
  const contract = await loadWeb3Contract(web3);
  await loadNFTS(contract);
  }, [])

  function buy(id, price) {
    if(id !== undefined) {
      console.log("ID IS: " + id);
      contract.methods.buyNFT(id).send( {from: account, value: web3.utils.toWei(price.toString(), "ether")}, (error) => {
        if(error) {
          console.log(error);
        }
    
      });
    }
  }

  function setStudentPrice(index, value) {
    if(value !== undefined) {
      // get all old students and save them in temp variable
      const data = [...students]
      data[index+1].price = value
      setStudents(data)
    }
  }

  const sell = (index) => {
    let weiPrice = web3.utils.toWei(students[index+1].price, "ether")
    contract.methods.setPrice(students[index+1].id, weiPrice).send({ from: account });
  }

  return <div>
<nav className="navbar navbar-light bg-light px-4">
  <a className="navbar-brand" href="#">Crypto Students</a>
  <span  className="navbar-brand" >{account}</span>
</nav>
<div className="container-fluid mt-5">
  <div className="row">
    <div className="col d-flex flex-column align-items-center">
      <div className="row-6">
      <img className="mb-4" src="https://avatars.dicebear.com/api/avataaars/Welcome.svg" alt="" width="85"/>
      <img className="mb-4" src="https://avatars.dicebear.com/api/avataaars/to_the.svg" alt="" width="85"/>
      <img className="mb-4" src="https://avatars.dicebear.com/api/avataaars/best.svg" alt="" width="85"/>
      <img className="mb-4" src="https://avatars.dicebear.com/api/avataaars/NFT_Marketplace.svg" alt="" width="85"/>
      </div>
      <h1 className="display-5 fw-bold">Create your own Crypto Student NFT!</h1>
      <div className="col-6 text-center mb-3" >
        <div>
          <input
            type="text"
            value={mintText}
            onChange={(e)=>setMintText(e.target.value)}
            className="form-control mb-2"
            placeholder="e.g. Beethoven" />
          <button onClick={mint} className="btn btn-primary">Mint</button>
        </div>
      </div>
      <br/>
      <br/>
      <br/>
      <h1>Your collection</h1>
      <div className="col-8 d-flex justify-content-center flex-wrap p-4">
 
          {students.slice(1, students.length).map((student, index) => {
            if (student.owner === account) {
              return (
                  <div className="d-flex flex-column align-items-center" key={index}>
                    <img width="150"
                         src={`https://avatars.dicebear.com/api/avataaars/${student.name.replace("#", "")}.svg`}/>
                    <span>{student.name}</span>
                    <div className="d-flex flex-row">
                      <input
                          type="number"
                          value={students[index + 1].price}
                          onChange={
                            (e) =>
                                setStudentPrice(index, e.target.value)
                          }
                          className="p-2"
                          placeholder="Set a price"/>
                      <button onClick={() => sell(index)} className="btn btn-primary p-2">Sell</button>
                    </div>
                  </div>
              )
            }
          })}
          
      </div>
      <br/>
      <br/>
      <br/>
      <h1>Buy Students</h1>
      <div className="col-8 d-flex justify-content-center flex-wrap p-4">
        {students.slice(1, students.length).map((student, index) => {
          if (student.price > 0 && student.owner !== account) {
            return (
              <div className="d-flex flex-column align-items-center" key={index}>
                <img width="150" src={`https://avatars.dicebear.com/api/avataaars/${student.name.replace("#", "")}.svg`} />
                <span>{student.name}</span>
                <div className="d-flex flex-row">
                  <button onClick={() => buy(student.id, student.price)} className="btn btn-primary p-2">Buy for {student.price} ETH</button>
                </div>
              </div>
          )
          }
        })
        }
      </div>
      <h1>See your friends NFTS</h1>
      <div className="col-8 d-flex justify-content-center flex-wrap">
      
        {students.slice(1, students.length).map((student, index) => {
          if (student.price == 0 && student.owner !== account) {
            let shortOwnerText = student.owner.substring(0, 10) + "..."
            return (
              <div className="d-flex flex-column align-items-center p-4" key={index}>
                <img width="150" src={`https://avatars.dicebear.com/api/avataaars/${student.name.replace("#", "")}.svg`} />
                <span>{student.name}</span>
                <span>Owner : {shortOwnerText}</span>
              </div>
          )
          }
        })
        }
      </div>

    </div>
  </div>
</div>
</div>;
};


export default App;
